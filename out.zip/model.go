package main

type Model struct {
	value string
}
