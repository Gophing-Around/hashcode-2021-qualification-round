package main

func printInputMetrics(input int) {

}

func printResultMetrics(result int) {

}
